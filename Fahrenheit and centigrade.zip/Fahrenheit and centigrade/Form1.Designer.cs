﻿namespace Fahrenheit_and_centigrade
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.lblFahrenheit = new System.Windows.Forms.Label();
            this.lblCentigrade = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblF = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(155, 53);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 80);
            this.vScrollBar1.TabIndex = 0;
            this.vScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar1_Scroll);
            // 
            // lblFahrenheit
            // 
            this.lblFahrenheit.AutoSize = true;
            this.lblFahrenheit.Location = new System.Drawing.Point(31, 53);
            this.lblFahrenheit.Name = "lblFahrenheit";
            this.lblFahrenheit.Size = new System.Drawing.Size(57, 13);
            this.lblFahrenheit.TabIndex = 1;
            this.lblFahrenheit.Text = "Fahrenheit";
            // 
            // lblCentigrade
            // 
            this.lblCentigrade.AutoSize = true;
            this.lblCentigrade.Location = new System.Drawing.Point(218, 53);
            this.lblCentigrade.Name = "lblCentigrade";
            this.lblCentigrade.Size = new System.Drawing.Size(58, 13);
            this.lblCentigrade.TabIndex = 2;
            this.lblCentigrade.Text = "Centigrade";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 195);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblF
            // 
            this.lblF.AutoSize = true;
            this.lblF.Location = new System.Drawing.Point(34, 91);
            this.lblF.Name = "lblF";
            this.lblF.Size = new System.Drawing.Size(35, 13);
            this.lblF.TabIndex = 6;
            this.lblF.Text = "label1";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(250, 90);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(35, 13);
            this.lblC.TabIndex = 7;
            this.lblC.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(424, 262);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblF);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblCentigrade);
            this.Controls.Add(this.lblFahrenheit);
            this.Controls.Add(this.vScrollBar1);
            this.Name = "Form1";
            this.Text = "Themometer2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Label lblFahrenheit;
        private System.Windows.Forms.Label lblCentigrade;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblF;
        private System.Windows.Forms.Label lblC;
    }
}

